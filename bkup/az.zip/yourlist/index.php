<?php session_start(); ?>
<!DOCTYPE html>
<?php include 'db.php';


// var_dump($_SESSION); exit;

$userid= $_SESSION['uid'];
$sql = "select * from tasks where listtype = (select distinct(listtype) from tasks where user='$userid' limit 1) and user='$userid'";

$rows = $db->query($sql);
?>


<html>

<head>
  <link rel="stylesheet" type="text/css" href="css/styles.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"
    integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
  <!-- Latest compiled and minified JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"
    integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous">
  </script>

  <title>Crud App</title>
</head>

<body>

  <div class="container">

    <a class="btn1" href="../">Back to eKart</a>

    <div class="row">
      <center>
        <h1 class="header-text">Todo list</h1>
      </center>

      <!--DIV WITH 10 COLUMNS
            MD = MEDIUM SIZE
            OFFSET OF 1 TO CENTER-->
      <div class="col-md-10 col-md-offset-1">
        <table class=" table table-hover">
          <button id="addtasknewone" type="button" data-target="#myModal" data-toggle="modal"
            class="btn btn-success">Add Task</button>



          <?php
            $sql1 = "SELECT DISTINCT(listtype) FROM tasks WHERE user='$userid'";
            $rows1 = $db->query($sql1);
            $count='1';
            echo '<section id="id_listname">';
            echo '<select id=listname>';
            while ($row1 = $rows1->fetch_assoc()) :
              $count==1 ? $selection = 'selected' : $selection = '';
              $listtype = $row1['listtype'];
              echo "<option $selection value='$listtype'>$listtype</option>";
              ++$count;
            endwhile;
                echo '</select>';
                echo '</section>';
         ?>



          <!-- <section id="id_listname">
            <select name="" id="">
              <option selected value="">Vegetable List</option>
              <option value="">Wish List</option>
              <option value="">Amazon List</option>
            </select> -->

          <button type="button" data-target="#myModalList" data-toggle="modal" class="btn btn-success">Add
            List</button>
          </section>

          <button type="button" class="btn btn-default pull-right" onclick="print()">Print</button>
          <hr>
          <?php
                  if (!empty($status)) {
                      echo '
                      <div class="">
                        <p> '. $status['msg'] .' <p>
                      </div>
                    ';
                  }
            ?>
          <br>

          <!-- Modal: Shows up a small screen with a message about the stuff, 
                    jQuery needed for this to work-->
          <div id="myModal" class="modal fade" role="dialog">
            <div class="modal-dialog">

              <!-- Modal content-->
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h4 class="modal-title">Add Task</h4>
                </div>
                <div class="modal-body">
                  <!-- <form method="POST" action="add.php" onsubmit="setval()"> -->
                  <!-- <form method="POST" onsubmit="addtask()"> -->
                  <div class="form-group">
                    <lable>Task Name</lable>
                    <input id="hd_name" type="text" required name="task" class="form-control" required>
                    <input id="hd_listtype" type="hidden" name="listtype" value="">
                  </div>
                  <input type="submit" name="send" value="Add Task" class="btn btn-success" onclick="addtask()"
                    data-dismiss="modal">
                  <!-- </form> -->
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
              </div>

            </div>
          </div>

          <div id="myModalList" class="modal fade" role="dialog">
            <div class="modal-dialog">

              <!-- Modal content-->
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h4 class="modal-title">Add New List</h4>
                </div>
                <div class="modal-body">
                  <form method="POST" action="addlist.php">
                    <div class="form-group">
                      <lable>List Name</lable>
                      <input type="text" required name="list" class="form-control">
                    </div>
                    <input type="submit" name="send" value="Add List" class="btn btn-success">
                  </form>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
              </div>

            </div>
          </div>

          <thead>
            <tr>
              <th scope="col">ID</th>
              <th scope="col">Task</th>
            </tr>
          </thead>
          <tbody id="result">
            <tr>
              <?php while ($row = $rows->fetch_assoc()) : ?>
              <th><?php echo $row['id'] ?>
              </th>
              <td class="col-md-10"><?php echo $row['name'] ?>
              </td>
              <td><a href="update.php?id=<?php echo $row['id'];?>" class="btn btn-success">Edit</a></td>
              <td><a id="<?php echo $row['id'];?>" class="btn btn-danger" onclick="delthisone(this)">Delete</a></td>
              <!-- <td><a id="<?php echo $row['id'];?>"
              href="delete.php?id=<?php echo $row['id'];?>"
              class="btn btn-danger">Delete</a></td> -->
            </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>

    </div>
  </div>


  <script src="js/master.js"></script>
</body>

</html>



<!-- UPDATE `tasks` SET `listtype` = 'fruit list' WHERE `tasks`.`id` = 1; -->
<!-- ALTER TABLE tasks ADD COLUMN `regdate` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP -->
<!-- INSERT INTO `tasks` (`id`, `name`, `listtype`, `user`, `regdate`) VALUES (NULL, 'Orange', 'fruit list', 'sj', CURRENT_TIMESTAMP); -->
<!-- ALTER TABLE `tasks` CHANGE `user` `user` VARCHAR(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT 'sj'; -->