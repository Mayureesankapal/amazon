<?php

// creates the connection with the database
$db = new mysqli;

$db->connect('localhost', 'root', '', 'onlineshoptodo');
// $db->connect('localhost', 'iClient', 'password', 'crud', '3306' ,'');

if (!$db) {
    echo "success";
}



// CREATE TABLE `onlineshoptodo`.`tasks` ( `id` INT NOT NULL AUTO_INCREMENT , `name` VARCHAR(255) NOT NULL , `regdate` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP , PRIMARY KEY (`id`)) ENGINE = InnoDB;