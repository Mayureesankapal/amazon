$(function(){

  $("#listname").change(function(){
    var listname = $('#listname').val();
    // $('#hd_listtype').val(listname);
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById("result").innerHTML = this.responseText;
      }
    };
    xmlhttp.open("GET", "getlistdata.php?listname=" + listname, true);
    xmlhttp.send();
  });

  $('#addtasknewone').click(function(){
    $('#hd_name').val('');
  });


});


function addtask(){
  var listname = document.getElementById("listname").value;
  document.getElementById("hd_listtype").value = listname;
  var hdname = document.getElementById("hd_name").value;
  
  var http = new XMLHttpRequest();
  var url = 'add.php';
  var params = 'task='+hdname+'&listtype='+listname;
  http.open('POST', url, true);
  
  //Send the proper header information along with the request
  http.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
  
  http.onreadystatechange = function() {//Call a function when the state changes.
      if(http.readyState == 4 && http.status == 200) {
        document.getElementById("result").innerHTML = http.responseText;
          // alert(http.responseText);
      }
  }
  http.send(params);
}

function delthisone(e) {
  // alert(e.id);

  var td = event.target.parentNode; 
      var tr = td.parentNode; // the row to be removed
      tr.parentNode.removeChild(tr);
  var e = e.id;
  var xmlhttp = new XMLHttpRequest();
  xmlhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      // document.getElementById("result").innerHTML = this.responseText;
    }
  };
  xmlhttp.open("GET", "delete.php?id=" + e, true);
  xmlhttp.send();
}