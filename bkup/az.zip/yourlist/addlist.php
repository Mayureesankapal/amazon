<?php
session_start();
include 'db.php';

$userid=$_SESSION['uid'];


if (isset($_POST['send'])) {
    $listtype = $_POST['list'];

    $sql = "insert into tasks (listtype, user) values ('$listtype', '$userid')";

    $val = $db->query($sql);

    if ($val) {
        header('location: index.php');
    }
}