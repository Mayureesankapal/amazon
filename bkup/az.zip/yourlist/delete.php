<?php
session_start();
include'db.php';

$userid=$_SESSION['uid'];

// the 'id' inside [] can be changed for whatever, but needs to be changed
//after the ? mark on the href of the delete button
$id = $_GET['id'];

$sql = "delete from tasks where id = '$id' and user='$userid'";

$val = $db->query($sql);

if ($val) {
    $status['msg']="Deleted Sucessfully!";
    // header('location: index.php');
};