<?php
session_start();
// var_dump($_SESSION);
// exit;
  $userid=$_SESSION['uid'];
  $listtype = $_GET['listname'];



  $sql = "select * from tasks where listtype = '$listtype' and user='$userid'";
  require_once 'db.php';
  $rows = $db->query($sql);
  echo '<tr>';
  while ($row = $rows->fetch_assoc()) :
    $id = $row['id'];
    $name = $row['name'];
  echo "
  <th>$id</th>
    <td class='col-md-10'>$name </td>
    <td><a href='update.php?id=$id' class='btn btn-success'>Edit</a></td>
    <td><a id='$id' class='btn btn-danger' onclick='delthisone(this)'>Delete</a></td>
  ";
  echo '</tr>';
  endwhile;