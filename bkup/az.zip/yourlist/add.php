<?php
session_start();
require_once 'db.php';

$userid=$_SESSION['uid'];




// if (isset($_POST['send'])) {
    $name = $_POST['task'];
    $listtype = $_POST['listtype'];

    $sql = "insert into tasks (name, listtype, user) values ('$name', '$listtype', '$userid')";

    $val = $db->query($sql);

    if ($val) {
        // echo "Successfully added list";
        // header('location: index.php');
        $sql = "select * from tasks where listtype = '$listtype'";
        $rows = $db->query($sql);
        echo '<tr>';
        while ($row = $rows->fetch_assoc()) :
    $id = $row['id'];
        $name = $row['name'];
        echo "
  <th>$id</th>
    <td class='col-md-10'>$name </td>
    <td><a href='update.php?id=$id' class='btn btn-success'>Edit</a></td>
    <td><a id='$id' class='btn btn-danger' onclick='delthisone(this)'>Delete</a></td>
  ";
        echo '</tr>';
        endwhile;
    }
// }